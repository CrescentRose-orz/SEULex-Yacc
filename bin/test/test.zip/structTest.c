
int main(){
int n;
	for (int i = 0 ; i < n; ++i){
		switch( i ){
			case 1:
				break;
			case 2:
				break;
			default:
				
		}
		continue;
		break;
	}
	return 0;
}
